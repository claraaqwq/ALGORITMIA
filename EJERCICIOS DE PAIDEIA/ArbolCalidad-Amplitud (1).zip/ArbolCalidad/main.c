/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: cueva
 *
 * Created on 30 de mayo de 2022, 11:44 AM
 */
#include "ab.h"
#include "abb.h"
#include "colas.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
 * 
 */

ABB busca(ABB parbol,int valor){
    if(parbol==NULL)
        return NULL;
    else{
        if(parbol->elemento.lote==valor)
            return parbol;
        else{
            if(parbol->elemento.lote<valor)
                parbol=parbol->hijo_der;
            else
                parbol=parbol->hijo_izq;
        return   busca(parbol,valor);
        }
    }
}


int valida(ABB arbol,int cali){
    ABB paux;
    Cola pcola;
    int num,cont=0;
    ElementoArbol temp;
    
    num = pow(2,cali-1);
    paux=arbol;
    
    if(paux==NULL) return 1;
    construir_cola(&pcola);
    temp.lote = paux->elemento.lote;
    temp.cant = paux->elemento.cant;        
    pide_vez(&pcola,temp);
    
    while(!es_cola_vacia(pcola)){
        temp = avanzar(&pcola);
        if(cali == temp.cant) cont++;
        paux = busca(arbol,temp.lote);
        
        if(paux->hijo_izq!=NULL){
            if(cali >= paux->hijo_izq->elemento.cant ){
                temp.lote = paux->hijo_izq->elemento.lote;
                temp.cant = paux->hijo_izq->elemento.cant;
                pide_vez(&pcola,temp);
            }
        }
        if(paux->hijo_der!=NULL){
            if(cali >= paux->hijo_der->elemento.cant ){
                temp.lote = paux->hijo_der->elemento.lote;
                temp.cant = paux->hijo_der->elemento.cant;
                pide_vez(&pcola,temp);
            }
        }
    }
    if(cont<num) return 1;
    return 0;
}

void imprime_amp(ABB ptrarbol){
    ABB paux;
    Cola pcola;
    ElementoArbol temp;
    
    paux = ptrarbol;
    if(paux==NULL) return;
    construir_cola(&pcola);
    temp.lote = paux->elemento.lote;
    temp.cant = paux->elemento.cant;
    pide_vez(&pcola,temp);
    while(!es_cola_vacia(pcola)){
        temp = avanzar(&pcola);
        printf("%3d-%3d   ",temp.lote,temp.cant);
        paux = busca(ptrarbol,temp.lote);
        if(paux->hijo_izq!=NULL){
            temp.cant = paux->hijo_izq->elemento.cant;
            temp.lote = paux->hijo_izq->elemento.lote;
            pide_vez(&pcola,temp);
        }    
        if(paux->hijo_der!=NULL){
            temp.cant = paux->hijo_der->elemento.cant;
            temp.lote = paux->hijo_der->elemento.lote;            
            pide_vez(&pcola,temp);
        }    
    }
    
}

int main(int argc, char** argv) {
    ABB arbol;
    ElementoArbol aux;
    
    construir_arbol_binario(&arbol);
    
    aux.cant = 1;
    aux.lote = 10;
    insertar(&arbol,aux);
    aux.cant = 2;
    aux.lote = 5;
    insertar(&arbol,aux);
    aux.cant = 2;
    aux.lote = 20;
    insertar(&arbol,aux);
    aux.cant = 3;
    aux.lote = 2;
    insertar(&arbol,aux);    
    aux.cant = 3;
    aux.lote = 6;
    insertar(&arbol,aux);
    aux.cant = 3;
    aux.lote = 21;
    insertar(&arbol,aux); 
    
    imprime_amp(arbol);
    printf("\n");
    pre_orden(arbol);
    printf("\n");

    printf("Se puede insertar:%d",valida(arbol,3));
    
    return (EXIT_SUCCESS); 
}

