#ifndef ABB_H
#define ABB_H
#include "ab.h"

typedef ArbolBinario ABB;

void insertar(ABB *, ElementoArbol);
void insertar_iterativo(ABB *, ElementoArbol);
int esta(ABB, ElementoArbol);
int esta_iterativo(ABB, ElementoArbol);
int minimo_valor(ABB);
int maximo_valor(ABB);
int minimo_iterativo(ABB);
int maximo_iterativo(ABB);

#endif