#include <stdio.h>
#include <stdlib.h>
#include "ab.h"
#include "abb.h"

void insertar(ABB *tad, ElementoArbol elemento){
	if (es_arbol_vacio(*tad))
		plantar_arbol_binario(tad, NULL, elemento, NULL);
	else{
		if ((*tad)->elemento.lote > elemento.lote)
			insertar(&(*tad)->hijo_izq, elemento);
		else
			insertar(&(*tad)->hijo_der, elemento);
	}
}

void insertar_iterativo(ABB *tad, ElementoArbol elemento){
	if (es_arbol_vacio(*tad))
		plantar_arbol_binario(tad, NULL, elemento, NULL);
	else{
		//parte 1. Se busca el padre de la hoja que se va a colocar
		ABB recorrido=*tad, padre=NULL;
		while(!es_arbol_vacio(recorrido)){
			padre=recorrido;
			if (recorrido->elemento.lote >elemento.lote)
				recorrido=recorrido->hijo_izq;
			else
				recorrido=recorrido->hijo_der;
		}

		//parte 2. Se planta la hoja en el árbol
		if (padre->elemento.lote >elemento.lote)
			plantar_arbol_binario(&padre->hijo_izq, NULL, elemento, NULL);
		else
			plantar_arbol_binario(&padre->hijo_der, NULL, elemento, NULL);
	}
}



